package com.example.myrecyclerviewerdemo;

public class MyData {

    static String[] nameArray = {"arthur", "baster", "fransin", "gily", "moffie",
            "ellen", "binky","teacher", "fronela", "gerege"};
    static String[] Description = {"Student at the music school", "Student at the music school",
            "Student at the music school", "Student at the music school", "Student at the music school",
            "Director of the music school", "Singing teacher at the music school", "Student at the music school",
            "Noa Shahar's Mother", "Noa Shahar's agent"};

    static Integer[] drawableArray = {R.drawable.arthur, R.drawable.baster, R.drawable.fransin,
            R.drawable.gily, R.drawable.moffie, R.drawable.ellen, R.drawable.binky,
            R.drawable.teacher, R.drawable.fronela, R.drawable.baster};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
}
